
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
app.use(express.json());
app.use(express.static('Public'));
app.use(cors());



mongoose.connect("mongodb://localhost:27017/Jobapplication");


app.use(express.static('Uploads'))

const jobRoutes = require('./Routes/jobs');
const applicationRoutes = require('./Routes/application');


app.use('/jobs', jobRoutes);
app.use('/applications', applicationRoutes);





app.listen(8000, () => {
    console.log(`Server is running on port 8000`);
});
